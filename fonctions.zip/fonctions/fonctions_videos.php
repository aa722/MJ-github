<?php
require_once 'connexion.php';

function recup_desc(String $titre){
    $con=se_connecter();
    try{
        $query=$con->prepare('SELECT* from video WHERE titre= :titre');
        $query->execute([':titre'=>$titre]);

        $tableau=$query->fetch(PDO::FETCH_ASSOC);
        
        if($tableau)
        {
            return $tableau;
        }
        else{
            echo'EChec';
        }

    }catch(PDOException $e){
        echo "Erreur: $e"; 
    }
}

?>